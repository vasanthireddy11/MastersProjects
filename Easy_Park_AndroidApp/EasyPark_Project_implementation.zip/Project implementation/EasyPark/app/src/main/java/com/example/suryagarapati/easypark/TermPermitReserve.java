package com.example.suryagarapati.easypark;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.ContentValues;
import android.database.Cursor;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.support.v7.app.AlertDialog;
import android.database.sqlite.SQLiteDatabase;

import com.example.suryagarapati.easypark.database.ParkDataHelper;
import com.example.suryagarapati.easypark.database.ParkCursorWrapper;

import com.example.suryagarapati.easypark.database.ParkDbSchema;


public class TermPermitReserve extends AppCompatActivity {
        private static final int ACTIVITY_CONSTANT = 0;
        private Context mContext;
        private SQLiteDatabase mDatabase;
        private int belltowerCount;
        private int sagehallCount;
        private int libraryCount;
        private int elradohallCount;
        public static Intent newIntent(Context packageContext) {
        Intent intent = new Intent(packageContext, TermPermitReserve.class);
        return intent;
    }

    TextView validerrorText;
    LinearLayout layout_to_reserve;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.term_permit_reserve);
            validerrorText = (TextView) findViewById(R.id.textView2);
            validerrorText.setVisibility(View.GONE);
            layout_to_reserve = (LinearLayout) findViewById(R.id.linearLayout2);
            //Get values from DB and update on UI.
            //------DB Cursor get dailyparkpermit for belltower-----
            mContext = this.getApplicationContext();
            mDatabase = new ParkDataHelper(mContext).getWritableDatabase();

            ContentValues values = new ContentValues();
            values.put(ParkDbSchema.termPermitNosTable.Cols.TERMPERMITNO, 1021);
            mDatabase.insert(ParkDbSchema.termPermitNosTable.NAME, null, values);

            String user = "TermParkPermit";
            ParkCursorWrapper cursor = queryPark(
                    ParkDbSchema.parkTable.Cols.USER + " = ?",
                    new String[] { user}
            );
            try {
                if (cursor.getCount() == 0) {
                    //  return null;
                }
                cursor.moveToFirst();
                ParkSlots p =  cursor.getSlots();
                //do something here to update ui
                belltowerCount =p.getBellTower();

                sagehallCount = p.getSageHall();

                libraryCount = p.getLibrary();

                elradohallCount = p.getElRadoHall();
                updateAllSlotsCountonUI();

            } finally {
                cursor.close();
            }
            layout_to_reserve.setVisibility(View.GONE);
    }
    public void updateAllSlotsCountonUI() {
        Button count_update_button = (Button)findViewById(R.id.buttonbelltowercount);
        count_update_button.setText(String.valueOf(belltowerCount));

        count_update_button = (Button)findViewById(R.id.buttonsagehallcount);
        count_update_button.setText(String.valueOf(sagehallCount));

        count_update_button = (Button)findViewById(R.id.buttonlibrarycount);
        count_update_button.setText(String.valueOf(libraryCount));

        count_update_button = (Button)findViewById(R.id.buttonelradocount);
        count_update_button.setText(String.valueOf(elradohallCount));
    }

        private ParkCursorWrapper queryPark(String whereClause, String[] whereArgs) {
        Cursor cursor = mDatabase.query(
                ParkDbSchema.parkTable.NAME,
                null, // columns - null selects all columns
                whereClause,
                whereArgs,
                null, // groupBy
                null, // having
                null  // orderBy
        );

        return new ParkCursorWrapper(cursor);
    }
    private ParkCursorWrapper queryTermPermits(int termpermitno) {
//        Cursor cursor = mDatabase.query(
//                ParkDbSchema.termPermitNosTable.NAME,
//                null, // columns - null selects all columns
//                whereClause,
//                whereArgs,
//                null, // groupBy
//                null, // having
//                null  // orderBy
//        );
        Cursor cursor = mDatabase.query(
                ParkDbSchema.termPermitNosTable.NAME, null,

                ParkDbSchema.termPermitNosTable.Cols.TERMPERMITNO   + "=" + termpermitno,
                null, null, null,
                null);

        return new ParkCursorWrapper(cursor);
    }
    public void termParkPayment(View v) {

        // setup the alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Reserve Slot");
        builder.setMessage("Would you like to reserve slot..");
        Button b = (Button)v;

       final String buttonText = b.getText().toString();
       final int button_id = b.getId();
        // add the buttons
      //  builder.setPositiveButton("Continue", null);
    //    builder.setNegativeButton("Cancel", null);

        builder.setPositiveButton("Reserve", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                dialog.dismiss();

                //   String parkingSpace = data.getExtras().getString("parkingSpace");
                String user1 = "TermParkPermit";
                ContentValues values1 = new ContentValues();
                Log.d("Test",  String.valueOf(button_id));
                values1.put(ParkDbSchema.parkTable.Cols.BELLTOWER, belltowerCount);

                switch (button_id) {
                    case R.id.buttonBellTower:
                        belltowerCount = belltowerCount-1;
                        values1.put(ParkDbSchema.parkTable.Cols.BELLTOWER, belltowerCount);
                        break;
                    case R.id.buttonSageHall:
                        sagehallCount = sagehallCount-1;
                        values1.put(ParkDbSchema.parkTable.Cols.SAGEHALL, sagehallCount);
                        break;
                    case R.id.buttonLibrary:
                        libraryCount = libraryCount-1;
                        values1.put(ParkDbSchema.parkTable.Cols.LIBRARY, libraryCount);
                        break;
                    case R.id.buttonElRadoHall:
                        elradohallCount = elradohallCount-1;
                        values1.put(ParkDbSchema.parkTable.Cols.ELRADOHALL, elradohallCount);
                        break;
                }

                updateAllSlotsCountonUI();

                mDatabase.update(ParkDbSchema.parkTable.NAME, values1,
                        ParkDbSchema.parkTable.Cols.USER + " = ?",
                        new String[] { user1 });
                String toastmsg = "Reserved slot at " +buttonText+" successfully";
                Toast.makeText(TermPermitReserve.this, toastmsg ,  Toast.LENGTH_SHORT).show();
                return;
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                return;
            }
        });

        // create and show the alert dialog
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(false);

        dialog.show();




    }

    public void ValidateTermPermitNo(View v) {
            //CHECK IN SQL FOR TERM PERMIT VALIDATION BASED ON THAT LOAD Ui page to reserve parking.
        int userTermPermit = 0;
        TextInputEditText txt;
        txt   = (TextInputEditText)findViewById(R.id.textinputid1);
        userTermPermit  = Integer.parseInt(txt.getText().toString());
//        ContentValues values = new ContentValues();
//        values.put(ParkDbSchema.termPermitNosTable.Cols.TERMPERMITNO, 1021);
//        mDatabase.insert(ParkDbSchema.termPermitNosTable.NAME, null, values);

        int validate = 2;
        ParkCursorWrapper cursor = queryTermPermits(userTermPermit);

        try {
            if (cursor.getCount() == 0) {
                //  return null;
                validate = 1;
            }
            else{
                validate = 2;
                cursor.moveToFirst();
               // TermPermits t =  cursor.getTermPermits();
                //do something here to update ui
               // int x =t.getTermPermitNo();
              //  Toast.makeText(TermPermitReserve.this, String.valueOf(x) ,  Toast.LENGTH_SHORT).show();
              //  Toast.makeText(TermPermitReserve.this, String.valueOf(userTermPermit) ,  Toast.LENGTH_SHORT).show();

                // ParkSlots p =  cursor.getSlots();
            }
        } finally {
            cursor.close();
        }

        if(validate ==1) {
            layout_to_reserve.setVisibility(View.GONE);
            validerrorText.setVisibility(View.VISIBLE);
        }
        else if(validate == 2){
            validerrorText.setVisibility(View.GONE);
            layout_to_reserve.setVisibility(View.VISIBLE);
            //AlertDialog alertDialog = alertDialogBuilder.create();
           // alertDialog.show();
        }
    }

//    @Override
//    public Dialog onCreateDialog(Bundle savedInstanceState) {
//        return new AlertDialog.Builder(getActivity())
//                .setTitle("YEYY MY DIALOG")
//                .setPositiveButton(android.R.string.ok, null)
//                .create();
//    }

}
