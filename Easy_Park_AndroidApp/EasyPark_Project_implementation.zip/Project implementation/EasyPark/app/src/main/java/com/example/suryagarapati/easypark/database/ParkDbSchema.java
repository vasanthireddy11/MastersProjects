package com.example.suryagarapati.easypark.database;

public class ParkDbSchema {
    public static final class parkTable {
        public static final String NAME = "easypark";

        public static final class Cols {
            public static final String BELLTOWER = "belltower";
            public static final String SAGEHALL = "sagehall";
            public static final String LIBRARY = "library";
            public static final String ELRADOHALL = "elradohall";
            public static final String USER = "user";

        }
    }
    //Deleted table
    public static final class termPermitNoTable {
        public static final String NAME = "termpermitnos";

        public static final class Cols {
            public static final String TERMPERMITNO = "termpemitno";
        }
    }
    public static final class termPermitNosTable {
        public static final String NAME = "termpermitno";

        public static final class Cols {
            public static final String TERMPERMITNO = "termpemitno";
        }
    }
}
