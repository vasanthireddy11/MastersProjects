package com.example.suryagarapati.easypark;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Button;
import android.widget.Toast;
import java.util.Calendar;
import java.util.Date;
import java.text.SimpleDateFormat;

import com.example.suryagarapati.easypark.database.ParkDataHelper;
import com.example.suryagarapati.easypark.database.ParkCursorWrapper;
import com.example.suryagarapati.easypark.database.ParkDbSchema;

public class DailyParkPermitPaymentFragment extends AppCompatActivity {
   // private Context mContext;
   // private SQLiteDatabase mDatabase;
    private static String sbuttonText = "";
    private static int button_id;
    public static Intent newIntent(Context packageContext, String buttonText) {
        Intent intent = new Intent(packageContext, DailyParkPermitPaymentFragment.class);
       sbuttonText = buttonText;


        return intent;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.daily_park_payment_fragment);

        Button parking_space_button = (Button)findViewById(R.id.buttonparkingSpace);
        String buttontext= "Slot Time:  " + System.getProperty("line.separator") +
                String.valueOf(sbuttonText)+System.getProperty("line.separator");

        Date todayDate = Calendar.getInstance().getTime();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
        String todayString = formatter.format(todayDate);
        buttontext = buttontext + todayString;
        parking_space_button.setText(String.valueOf(buttontext));

    }
    protected void dailyParkPaymentCancel(View v){
        setResult(2);
        finish();
    }
//    private ParkCursorWrapper queryPark(String whereClause, String[] whereArgs) {
//        Cursor cursor = mDatabase.query(
//                ParkDbSchema.parkTable.NAME,
//                null, // columns - null selects all columns
//                whereClause,
//                whereArgs,
//                null, // groupBy
//                null, // having
//                null  // orderBy
//        );
//
//        return new ParkCursorWrapper(cursor);
//    }
    protected void dailyParkPaymentConfirm(View v) {

        Toast.makeText(DailyParkPermitPaymentFragment.this,  sbuttonText,  Toast.LENGTH_SHORT).show();

        final Intent data = new Intent();
    //    int updatedcount =0;
   //     mContext = this.getApplicationContext();
     //   mDatabase = new ParkDataHelper(mContext).getWritableDatabase();
//        String column1 = "ALTER TABLE park ADD COLUMN sagehall INTEGER;";
//                mDatabase.execSQL(column1);
//        String column2 = "ALTER TABLE park ADD COLUMN library INTEGER;";
//        mDatabase.execSQL(column2);
//        String column3 = "ALTER TABLE park ADD COLUMN elradohall INTEGER;";
//        mDatabase.execSQL(column3);

//        ContentValues values = new ContentValues();
//        values.put(ParkDbSchema.parkTable.Cols.BELLTOWER, 150);
//        values.put(ParkDbSchema.parkTable.Cols.SAGEHALL, 80);
//        values.put(ParkDbSchema.parkTable.Cols.LIBRARY, 30);
//        values.put(ParkDbSchema.parkTable.Cols.ELRADOHALL, 90);
//        values.put(ParkDbSchema.parkTable.Cols.USER, "DailyParkPermit");
//
//        mDatabase.insert(ParkDbSchema.parkTable.NAME, null, values);


        //------DB Cursor get dailyparkpermit for belltower-----
//        String user = "DailyParkPermit";
//        ParkCursorWrapper cursor = queryPark(
//                ParkDbSchema.parkTable.Cols.USER + " = ?",
//                new String[] { user}
//        );
//        try {
//            if (cursor.getCount() == 0) {
//              //  return null;
//            }
//            cursor.moveToFirst();
//            ParkSlots p =  cursor.getSlots();
//           // data.putExtra("belTower", p.getBellTower());
//            updatedcount = p.getBellTower()-1;
//
//        } finally {
//            cursor.close();
//        }
        //  Toast.makeText(activity_set_reminder.this, "iuuou" , Toast.LENGTH_SHORT).show();
        //Decrement

        //Update DB--------
//       String user1 = "DailyParkPermit";
//         ContentValues values1 = new ContentValues();
//         values1.put(ParkDbSchema.parkTable.Cols.BELLTOWER, updatedcount);
//
//
//        mDatabase.update(ParkDbSchema.parkTable.NAME, values1,
//                ParkDbSchema.parkTable.Cols.USER + " = ?",
//                new String[] { user1 });

        //Update done
        data.putExtra("parkingSpace", sbuttonText);
        // setup the alert builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Payment Confirmation");
        builder.setMessage("Would you like to pay $6...");
        Button b = (Button)v;

        final String buttonText = b.getText().toString();
        final int button_id = b.getId();
        // add the buttons
        //  builder.setPositiveButton("Continue", null);
        //    builder.setNegativeButton("Cancel", null);

        builder.setPositiveButton("Pay", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int whichButton) {
                dialog.dismiss();
                 setResult(1, data);

                //setResult(1);
                finish();
                return;
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                return;
            }
        });

        // create and show the alert dialog
        AlertDialog dialog = builder.create();
        dialog.setCanceledOnTouchOutside(false);
        dialog.setCancelable(false);

        dialog.show();


      //  setResult(1, data);

        //setResult(1);
       // finish();

        //update count by sql
    }
}
