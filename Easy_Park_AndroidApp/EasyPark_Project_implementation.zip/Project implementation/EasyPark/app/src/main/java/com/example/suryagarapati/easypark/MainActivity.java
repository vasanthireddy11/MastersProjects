package com.example.suryagarapati.easypark;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.Spinner;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private static final int ACTIVITY_CONSTANT = 0;
    private RadioGroup radioGroup;
    private RadioButton radioButton;
    private Button btnDisplay;
    public static Intent newIntent(Context packageContext) {
        Intent intent = new Intent(packageContext, MainActivity.class);
        return intent;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void dailyPermit() {
        Intent intent = DailyPermitPark.newIntent(MainActivity.this);
        startActivityForResult(intent, ACTIVITY_CONSTANT);
       // Toast.makeText(MainActivity.this,  "test",  Toast.LENGTH_SHORT).show();
    }
    public void termPermit() {
        Intent intent = TermPermitReserve.newIntent(MainActivity.this);
        startActivityForResult(intent, ACTIVITY_CONSTANT);
        // Toast.makeText(MainActivity.this,  "test",  Toast.LENGTH_SHORT).show();
    }
    public void facultyPermit() {
        Intent intent = FacultyPermitReserve.newIntent(MainActivity.this);
        startActivityForResult(intent, ACTIVITY_CONSTANT);
        // Toast.makeText(MainActivity.this,  "test",  Toast.LENGTH_SHORT).show();
    }
    public void SignIn(View v){

        radioGroup = (RadioGroup) findViewById(R.id.radioGroup1);

        // get selected radio button from radioGroup
        int selectedId = radioGroup.getCheckedRadioButtonId();

        // find the radiobutton by returned id
        radioButton = (RadioButton) findViewById(selectedId);

//        Toast.makeText(MainActivity.this,
//                radioButton.getText(), Toast.LENGTH_SHORT).show();


        if(R.id.radio0 == radioButton.getId()){
            //Toast.makeText(MainActivity.this, radioButton.getText(), Toast.LENGTH_SHORT).show();
            dailyPermit();
        }
        if(R.id.radio1 == radioButton.getId()){
       //     Toast.makeText(MainActivity.this, radioButton.getText(), Toast.LENGTH_SHORT).show();
            facultyPermit();
        }
        if(R.id.radio2 == radioButton.getId()){
            //     Toast.makeText(MainActivity.this, radioButton.getText(), Toast.LENGTH_SHORT).show();
            termPermit();        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){

        }
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);

        //savedInstanceState.putStringArrayList(KEY_INDEX,items);
    }

}
