package com.example.suryagarapati.easypark;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class UserPage extends AppCompatActivity {
    private static final int ACTIVITY_CONSTANT = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.easypark_main);
    }
    public void loadMainActivity(View v) {
        Button b = (Button)v;

        Intent intent = MainActivity.newIntent(UserPage.this);
        startActivityForResult(intent, ACTIVITY_CONSTANT);
    }
}
