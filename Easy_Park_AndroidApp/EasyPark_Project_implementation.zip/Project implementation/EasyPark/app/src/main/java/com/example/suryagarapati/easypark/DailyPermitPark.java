package com.example.suryagarapati.easypark;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.widget.Button;

import com.example.suryagarapati.easypark.database.ParkDataHelper;
import com.example.suryagarapati.easypark.database.ParkCursorWrapper;
import com.example.suryagarapati.easypark.database.ParkDbSchema;

public class DailyPermitPark extends AppCompatActivity {
    private static final int ACTIVITY_CONSTANT = 0;
    private Context mContext;
    private SQLiteDatabase mDatabase;
    private int belltowerCount;
    private int sagehallCount;
    private int libraryCount;
    private int elradohallCount;
    private String  buttonText;
    private int button_id;
    public static Intent newIntent(Context packageContext) {
        Intent intent = new Intent(packageContext, DailyPermitPark.class);
        return intent;
    }
    private ParkCursorWrapper queryPark(String whereClause, String[] whereArgs) {
        Cursor cursor = mDatabase.query(
                ParkDbSchema.parkTable.NAME,
                null, // columns - null selects all columns
                whereClause,
                whereArgs,
                null, // groupBy
                null, // having
                null  // orderBy
        );

        return new ParkCursorWrapper(cursor);
    }
   // Intent data = new Intent();
   // int updatedcount =0;
    //mContext = this.getApplicationContext();
   // mDatabase = new ParkDataHelper(mContext).getWritableDatabase();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.daily_permit_park);
        getAllSlotsCountFromDb();

    }
    public void getAllSlotsCountFromDb() {
        mContext = this.getApplicationContext();
        mDatabase = new ParkDataHelper(mContext).getWritableDatabase();

        String user = "DailyParkPermit";
        ParkCursorWrapper cursor = queryPark(
                ParkDbSchema.parkTable.Cols.USER + " = ?",
                new String[] { user}
        );
        try {
            if (cursor.getCount() == 0) {
                //  return null;
            }
            cursor.moveToFirst();
            ParkSlots p =  cursor.getSlots();
            //do something here to update ui
            belltowerCount =p.getBellTower();

            sagehallCount = p.getSageHall();

            libraryCount = p.getLibrary();

            elradohallCount = p.getElRadoHall();
            updateAllSlotsCountonUI();



        } finally {
            cursor.close();
        }

    }
    public void updateAllSlotsCountonUI() {
        Button count_update_button = (Button)findViewById(R.id.buttonbelltowercount);
        count_update_button.setText(String.valueOf(belltowerCount));

        count_update_button = (Button)findViewById(R.id.buttonsagehallcount);
        count_update_button.setText(String.valueOf(sagehallCount));

        count_update_button = (Button)findViewById(R.id.buttonlibrarycount);
        count_update_button.setText(String.valueOf(libraryCount));

        count_update_button = (Button)findViewById(R.id.buttonelradocount);
        count_update_button.setText(String.valueOf(elradohallCount));
    }
    public void dailyParkPayment(View v) {
        Button b = (Button)v;

        buttonText = b.getText().toString();
        button_id = b.getId();
        Intent intent = DailyParkPermitPaymentFragment.newIntent(DailyPermitPark.this, buttonText);
        startActivityForResult(intent, ACTIVITY_CONSTANT);
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        if(resultCode == 1) {

         //   String parkingSpace = data.getExtras().getString("parkingSpace");
            String user1 = "DailyParkPermit";
            ContentValues values1 = new ContentValues();
            Log.d("Test",  String.valueOf(button_id));
            values1.put(ParkDbSchema.parkTable.Cols.BELLTOWER, belltowerCount);


            switch (button_id) {
                case R.id.buttonBellTower:
                    belltowerCount = belltowerCount-1;
                    values1.put(ParkDbSchema.parkTable.Cols.BELLTOWER, belltowerCount);
                    break;
                case R.id.buttonSageHall:
                    sagehallCount = sagehallCount-1;
                    values1.put(ParkDbSchema.parkTable.Cols.SAGEHALL, sagehallCount);
                    break;
                case R.id.buttonLibrary:
                    libraryCount = libraryCount-1;
                    values1.put(ParkDbSchema.parkTable.Cols.LIBRARY, libraryCount);
                    break;
                case R.id.buttonElRadoHall:
                    elradohallCount = elradohallCount-1;
                    values1.put(ParkDbSchema.parkTable.Cols.ELRADOHALL, elradohallCount);
                    break;
            }

            updateAllSlotsCountonUI();



            mDatabase.update(ParkDbSchema.parkTable.NAME, values1,
                    ParkDbSchema.parkTable.Cols.USER + " = ?",
                    new String[] { user1 });
            String toastmsg = "Payment Successful and Reserved slot at " +buttonText+"";

            Toast.makeText(DailyPermitPark.this, toastmsg ,  Toast.LENGTH_SHORT).show();
        //update sql (decrement teh count of bell tower)
        }
    }
}