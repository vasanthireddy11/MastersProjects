package com.example.suryagarapati.easypark.database;

public class TermPermitCursorWrapper {
}
