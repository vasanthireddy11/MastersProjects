package com.example.suryagarapati.easypark.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import com.example.suryagarapati.easypark.database.ParkDbSchema.parkTable;
import com.example.suryagarapati.easypark.database.ParkDbSchema.termPermitNoTable;
import com.example.suryagarapati.easypark.database.ParkDbSchema.termPermitNosTable;



public class ParkDataHelper extends SQLiteOpenHelper {
    private static final int VERSION = 3;
    private static final String DATABASE_NAME = "parkSlotsDb.db";

    public ParkDataHelper(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " + parkTable.NAME + "(" +
                " _id integer primary key autoincrement, " +
                parkTable.Cols.BELLTOWER +", " +
                parkTable.Cols.SAGEHALL +", " +
                parkTable.Cols.LIBRARY +", " +
                parkTable.Cols.ELRADOHALL +", " +
                parkTable.Cols.USER  +

                ")"
        );
        db.execSQL("create table " + termPermitNosTable.NAME + "(" +
                " _id integer primary key autoincrement, " +
                termPermitNosTable.Cols.TERMPERMITNO +
                ")"
        );
     //   db.execSQL("DROP TABLE IF EXISTS " + termPermitNoTable.NAME);
        db.execSQL("create table " + termPermitNosTable.NAME + "(" +
                " _id integer primary key autoincrement, " +
                termPermitNosTable.Cols.TERMPERMITNO +
                ")"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
       // onCreate(db);
    }
}
