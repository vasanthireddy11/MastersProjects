package com.example.suryagarapati.easypark;


public class ParkSlots {
    private String mUsers;
    private int mbellTower;
    private int msageHall;
    private int mlibrary;
    private int melRadoHall;


    public String getUser() {
        return mUsers;
    }

    public void setUser(String user) {
        mUsers = user;
    }

    public int getBellTower() {
        return mbellTower;
    }

    public void setBellTower(int bellTowerSlots) {
        mbellTower = bellTowerSlots;
    }
    public int getSageHall() {
        return msageHall;
    }

    public void setSageHall(int sageHallSlots) {
        msageHall = sageHallSlots;
    }
    public int getLibrary() {
        return mlibrary;
    }

    public void setLibrary(int librarySlots) {
        mlibrary = librarySlots;
    }
    public int getElRadoHall() {
        return melRadoHall;
    }

    public void setElRadoHall(int elRadoHallSlots) {
        melRadoHall = elRadoHallSlots;
    }



}
