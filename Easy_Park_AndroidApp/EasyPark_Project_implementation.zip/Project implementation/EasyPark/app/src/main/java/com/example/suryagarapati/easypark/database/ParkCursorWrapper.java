package com.example.suryagarapati.easypark.database;

import android.database.Cursor;
import android.database.CursorWrapper;

import com.example.suryagarapati.easypark.ParkSlots;
import com.example.suryagarapati.easypark.TermPermits;


public class ParkCursorWrapper extends CursorWrapper {
    public ParkCursorWrapper(Cursor cursor) {
        super(cursor);
    }

    public ParkSlots getSlots() {
        int belltower = getInt(getColumnIndex(ParkDbSchema.parkTable.Cols.BELLTOWER));
        int sagehall = getInt(getColumnIndex(ParkDbSchema.parkTable.Cols.SAGEHALL));
        int library = getInt(getColumnIndex(ParkDbSchema.parkTable.Cols.LIBRARY));
        int elradohall = getInt(getColumnIndex(ParkDbSchema.parkTable.Cols.ELRADOHALL));
        String user = getString(getColumnIndex(ParkDbSchema.parkTable.Cols.USER));

       // int belltower = getInt(ParkDbSchema.parkTable.Cols.BELLTOWER);
        //int title = getString(getColumnIndex(ParkDbSchema.CrimeTable.Cols.TITLE));
       // int date = getLong(getColumnIndex(ParkDbSchema.CrimeTable.Cols.DATE));
        //int isSolved = getInt(getColumnIndex(ParkDbSchema.CrimeTable.Cols.SOLVED));

        ParkSlots parkslots = new ParkSlots();
        parkslots.setBellTower(belltower);
        parkslots.setSageHall(sagehall);
        parkslots.setLibrary(library);
        parkslots.setElRadoHall(elradohall);
        parkslots.setUser(user);

        return parkslots;
    }
    public TermPermits getTermPermits() {
        int permitNo = getInt(getColumnIndex(ParkDbSchema.termPermitNosTable.Cols.TERMPERMITNO));
        TermPermits termpermits = new TermPermits();
        termpermits.setTermpermitNo(permitNo);
        return termpermits;


    }

}
