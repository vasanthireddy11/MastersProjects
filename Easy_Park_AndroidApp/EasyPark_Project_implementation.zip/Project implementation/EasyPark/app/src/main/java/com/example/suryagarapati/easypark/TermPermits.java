package com.example.suryagarapati.easypark;

public class TermPermits {

    private int mtermpermitno;




    public int getTermPermitNo() {
        return mtermpermitno;
    }

    public void setTermpermitNo(int termpermitno) {
        mtermpermitno = termpermitno;
    }

}
