package com.mcnz.restful.java.model;

public class myDataModel {

private String movieName ="from Model Data java class";
 

public String getMovieName() {
 return movieName;
 }

public void setMovieName(String movieName) {
 this.movieName = movieName;
 }


}