    i1=imread('backpack13.jpg');
    i2=rgb2gray(i1);
    upper = 230;
    lower = 230;
    i2(i2 >= upper) = 255;
    i2(i2 <= lower) = 0;
    bw1 = bwmorph(i2, 'clean');
    bw2=imcomplement(bw1);
     bw2=imfill(bw2,'holes');
     se= strel('disk',7);
    bw3=imopen(bw2,se);
    L = bwlabel(bw3);
L1 = label2rgb(L, @jet, [.5 .5 .5]);
s = regionprops(L, 'Centroid');
imshow(L1)
hold on

for k = 1:numel(s)
    disp(k);
    c = s(k).Centroid;
    text(c(1), c(2), sprintf('%d', k), ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'middle');
end
hold off
    %figure
    %montage({i1,i2,bw3})
    stats=regionprops(bw2,'Area','Eccentricity','Circularity','Extent');
    area=stats(1).Area;    eccen=stats(1).Eccentricity;
    circu=stats(1).Circularity;
    ext=stats(1).Extent;
    disp("Region props for Sneaker:")
    disp(stats);

    stats=regionprops(bw2,'Area','Eccentricity','Circularity','Extent');
    area=stats(1).Area;    eccen=stats(1).Eccentricity;
    circu=stats(1).Circularity;
    ext=stats(1).Extent;
    if ext<0.72
        if ext<0.5265
            figure;
         subplot(2,2,1),imshow(i1), title('Original Iamge');
        subplot(2,2,2),imshow(bw2), title('Grayscaled Iamge'); 
            subplot(2,2,3),imshow(L1), title('Segmented Image');
            subplot(2,2,4),imshow(i1); title('Classified as Sandal');
        else
           if eccen<0.7236
               if circu < 0.59308
                   figure;
         subplot(2,2,1),imshow(i1), title('Original Iamge');
        subplot(2,2,2),imshow(bw2), title('Grayscaled Iamge'); 
            subplot(2,2,3),imshow(L1), title('Segmented Image');
            subplot(2,2,4),imshow(i1); title('Classified as Hoodie');
                   
               else 
                      figure;
         subplot(2,2,1),imshow(i1), title('Original Iamge');
             subplot(2,2,2),imshow(bw2), title('Grayscaled Iamge'); 
                 subplot(2,2,3),imshow(L1), title('Segmented Image');
                        subplot(2,2,4),imshow(i1); title('Classified as T-shirt');
                   
               end
           else
               if circu < 0.6248
                   if area >= 26269
                       figure;
         subplot(2,2,1),imshow(i1), title('Original Iamge');
             subplot(2,2,2),imshow(bw2), title('Grayscaled Iamge'); 
                 subplot(2,2,3),imshow(L1), title('Segmented Image');
                        subplot(2,2,4),imshow(i1); title('Classified as Sneakers');
              
                   else
                     figure;
         subplot(2,2,1),imshow(i1), title('Original Iamge');
             subplot(2,2,2),imshow(bw2), title('Grayscaled Iamge'); 
                 subplot(2,2,3),imshow(L1), title('Segmented Image');
                        subplot(2,2,4),imshow(i1); title('Most Likely sneaker with pb 0.70 and T-shirt with 0.25');
              
                   end
               else
                  figure;
         subplot(2,2,1),imshow(i1), title('Original Iamge');
             subplot(2,2,2),imshow(bw2), title('Grayscaled Iamge'); 
                 subplot(2,2,3),imshow(L1), title('Segmented Image');
                        subplot(2,2,4),imshow(i1); title('Most Likely T-shirt with pb 0.46 or sneaker with pb 0.249');
               end
           end
           
           
        end
    else 
        if eccen >= 0.869
          figure;
         subplot(2,2,1),imshow(i1), title('Original Iamge');
        subplot(2,2,2),imshow(bw2), title('Grayscaled Iamge'); 
            subplot(2,2,3),imshow(L1), title('Segmented Image');
            subplot(2,2,4),imshow(i1); title('Classified as Trousers');
        
        else
            figure;
            subplot(2,2,1),imshow(i1), title('Original Iamge');
        subplot(2,2,2),imshow(bw2), title('Grayscaled Iamge'); 
            subplot(2,2,3),imshow(L1), title('Segmented');
            subplot(2,2,4),imshow(i1); title(' Backpack with pb of 0.78');
      
        end
    end
    



