i1=imread('pant11.jpg');
    i2=rgb2gray(i1);
    upper = 230;
    lower = 230;
    i2(i2 >= upper) = 255;
    i2(i2 <= lower) = 0;
    bw1 = bwmorph(i2, 'clean');
    bw2=imcomplement(bw1);
    bw2=imfill(bw2,'holes');
    se= strel('disk',7);
    bw3=imopen(bw2,se);
    stats=regionprops(bw2,'Area','Eccentricity','Circularity','Extent');
    area=stats(1).Area;    eccen=stats(1).Eccentricity;
    circu=stats(1).Circularity;
    ext=stats(1).Extent;
    if ext<0.72
        if ext<0.5265
            figure,imshow(i1);
            title('Sandal');
        else
           if eccen<0.7236
               if circu < 0.59308
                    figure,imshow(i1);
                    title('Hoodie');
               else 
                    figure,imshow(i1);
                    title('T-shirt');
               end
           else
               if circu < 0.6248
                   if area >= 26269
                        figure,imshow(i1);
                         title('Sneaker');
                   else
                        figure,imshow(i1);
                        title('Most Likely sneaker with pb 0.70 and T-shirt with 0.25');
                   end
               else
                   figure,imshow(i1);
                    title('Most Likely T-shirt with pb 0.46 or sneaker with pb 0.249');
               end
           end
           
           
        end
    else 
        if eccen >= 0.869
            figure,imshow(i1);
            title('Trousers');
        else
            figure,imshow(i1);
            title('Backpack with probability of 0.78 and hoodie with 0.18');
        end
    end
    