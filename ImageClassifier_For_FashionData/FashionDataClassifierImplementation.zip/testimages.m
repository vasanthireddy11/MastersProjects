    i1=imread('sneaker9.jpg');
    i2=rgb2gray(i1);
    upper = 230;
    lower = 230;
    i2(i2 >= upper) = 255;
    i2(i2 <= lower) = 0;
    bw1 = bwmorph(i2, 'clean');
    bw2=imcomplement(bw1);
    bw2=imfill(bw2,'holes');
     se= strel('disk',7);
    bw3=imopen(bw2,se);
      figure;
         subplot(1,3,1),imshow(i1), title('Original Image');
         subplot(1,3,2),imshow(bw2), title('Grayscaled Image'); 
         subplot(1,3,3),imshow(bw3), title('   Smoothened Image'); 
          
           L = bwlabel(bw3);
L1 = label2rgb(L, @jet, [.5 .5 .5]);
s = regionprops(L, 'Centroid');
   subplot(1,3,1),imshow(i1), title('Original Image');
         subplot(1,3,2),imshow(bw3), title('Smoothened Image'); 
         subplot(1,3,3),imshow(L1), title('   Segmented & labelled'); 
hold on

for k = 1:numel(s)
    disp(k);
    c = s(k).Centroid;
    text(c(1), c(2), sprintf('%d', k), ...
        'HorizontalAlignment', 'center', ...
        'VerticalAlignment', 'middle');
end
hold off
         